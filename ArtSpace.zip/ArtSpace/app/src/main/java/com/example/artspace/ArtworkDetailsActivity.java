package com.example.artspace;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ArtworkDetailsActivity extends AppCompatActivity {

    TextView txtDetails;
    Button btnBack, btnWebsite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artwork_details);

        txtDetails = findViewById(R.id.txtDetails);
        btnBack = findViewById(R.id.btnBack);
        btnWebsite = findViewById(R.id.btnWebsite);

        // Receive data from MainActivity
        String title = getIntent().getStringExtra("title");
        String artist = getIntent().getStringExtra("artist");
        String year = getIntent().getStringExtra("year");

        if (title == null) title = "N/A";
        if (artist == null) artist = "N/A";
        if (year == null) year = "N/A";

        txtDetails.setText(
                "Artwork: " + title +
                        "\n\nArtist: " + artist +
                        "\n\nYear: " + year
        );

        // Return to main activity
        btnBack.setOnClickListener(v -> finish());

        // Open external website safely
        btnWebsite.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.metmuseum.org/")
            );
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "No browser app found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}