package com.example.artspace;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String KEY_CURRENT_INDEX = "currentIndex";

    ImageView imgArtwork;
    TextView txtCounter, txtTitle, txtArtist;
    Button btnPrevious, btnNext;

    int currentIndex = 0;

    // Artwork images
    int[] images = {
            R.drawable.art1,
            R.drawable.art2,
            R.drawable.art3,
            R.drawable.art4,
            R.drawable.art5,
            R.drawable.art6
    };

    // Artwork titles
    String[] titles = {
            "The Starry Night",
            "Mona Lisa",
            "The Scream",
            "Water Lilies",
            "Girl with a Pearl Earring",
            "The Birth of Venus"
    };

    // Artists names
    String[] artists = {
            "Vincent van Gogh",
            "Leonardo da Vinci",
            "Edvard Munch",
            "Claude Monet",
            "Johannes Vermeer",
            "Sandro Botticelli"
    };

    // Artwork years
    String[] years = {
            "1889",
            "1503",
            "1893",
            "1916",
            "1665",
            "1485"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgArtwork = findViewById(R.id.imgArtwork);
        txtCounter = findViewById(R.id.txtCounter);
        txtTitle = findViewById(R.id.txtTitle);
        txtArtist = findViewById(R.id.txtArtist);

        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);

        // Restore saved position safely
        if (savedInstanceState != null) {
            int savedIndex = savedInstanceState.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < images.length) {
                currentIndex = savedIndex;
            }
        }

        updateArtwork();

        // Next button
        btnNext.setOnClickListener(v -> {
            if (currentIndex < images.length - 1) {
                currentIndex++;
                updateArtwork();
            }
        });

        // Previous button
        btnPrevious.setOnClickListener(v -> {
            if (currentIndex > 0) {
                currentIndex--;
                updateArtwork();
            }
        });

        // Open artwork details
        imgArtwork.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ArtworkDetailsActivity.class);
            intent.putExtra("title", titles[currentIndex]);
            intent.putExtra("artist", artists[currentIndex]);
            intent.putExtra("year", years[currentIndex]);
            startActivity(intent);
        });
    }

    // Update artwork information
    private void updateArtwork() {
        imgArtwork.setImageResource(images[currentIndex]);
        txtTitle.setText(titles[currentIndex]);
        txtArtist.setText(artists[currentIndex] + " - " + years[currentIndex]);
        txtCounter.setText((currentIndex + 1) + " / " + images.length);

        // Disable buttons at first and last artwork
        btnPrevious.setEnabled(currentIndex > 0);
        btnNext.setEnabled(currentIndex < images.length - 1);
    }

    // Save current artwork position
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_CURRENT_INDEX, currentIndex);
    }
}